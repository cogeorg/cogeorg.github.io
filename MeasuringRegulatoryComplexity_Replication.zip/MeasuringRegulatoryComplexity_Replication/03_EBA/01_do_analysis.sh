#!/usr/bin/env bash
# OPTIMIZED FOR OS X

./process_text.py ./Source_datasets/EBA-individual/ ./Source_datasets/EBA_Dictionary.csv ./Source_datasets/EBA_processed/
cd ./Source_datasets/EBA_processed/ ; rm all_cons-count.csv 2>/dev/null ; cat cons-count_* >> all_cons-count.csv ; cd -
