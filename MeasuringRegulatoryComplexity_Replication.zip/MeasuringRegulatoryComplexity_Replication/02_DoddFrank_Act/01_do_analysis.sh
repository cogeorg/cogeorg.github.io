#!/usr/bin/env bash
# OPTIMIZED FOR OS X

./process_text.py ./Source_datasets/DFA-titles_txt/ ./Source_datasets/DFA_Dictionary.csv ./Source_datasets/DFA-titles_processed/
cd ./Source_datasets/DFA-titles_processed/ ; rm all_cons-count.csv 2>/dev/null ; cat cons-count_* >> all_cons-count.csv ; cd -

