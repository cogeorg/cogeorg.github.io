#!/bin/bash
#
# FIG1
#
#rm production/plots/Fig1/*.dat
#cd production/measurements/Fig1;
#for j in 0.25-0.75 0.4-0.6 0.49-0.51 ; do for i in 0.01 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.6 0.7 0.8 0.9 1.0 ; do echo -n "$i " >> ../../plots/Fig1/$j-res-actions.dat ; cat *$j-$i*-res-#actions.dat >> ../../plots/Fig1/$j-res-actions.dat ; done ; done
#cd ../../plots/Fig1
#cat 12_create_plots.gp | gnuplot 
#ps2pdf Fig1.eps
#mv Fig1.* ~/Dropbox/papers/2013/Georg_NetworkFormation/Figures/

#
# FIG2
#
cd production/measurements/Fig2;
cat 12_create_plots.gp | gnuplot
ps2pdf Fig2.eps
mv Fig2.* ~/Dropbox/papers/2013/Georg_NetworkFormation/Figures/
