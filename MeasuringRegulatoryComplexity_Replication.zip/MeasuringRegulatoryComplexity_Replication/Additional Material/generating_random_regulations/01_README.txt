# README

To generate random regulations as described in the paper "Measuring Regulatory Complexity", execute the bash shell script 10_generate_regulations.sh in this folder. 

The regulations used in the experiments described in the paper are in ./10_regulations/exercises_website/ and then in individual folders.

The other files in this folder are only to analyze the complexity of the generated regulations.